//var chalk = require('chalk');
import chalk from 'chalk';

// Excepciones a la regla de no console:
/* eslint-disable no-console */
console.log(chalk.green('Starting app in dev mode...'));
