PUser.find({}).exec(function(err, result) {
      if (!err) {
        // handle result
      } else {
        // error handling
      };
    });
