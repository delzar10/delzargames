/* eslint-disable no-unused-vars */
import fetch from 'whatwg-fetch';